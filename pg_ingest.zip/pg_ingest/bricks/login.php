<h1>Welcome Maintainer!</h1>
<form role="pg_auth" id="pg_auth" action="index.php" method="POST">
    <label for="pg_role">
        <span class="ml"></span>
    </label>
    <input type="text" name="pg_role" id="pg_role">
    <label for="pg_pwd">
        <span class="ml"></span>
    </label>
    <input type="password" name="pg_pwd" id="pg_pwd">
    <input type="submit" value="GO">
</form>
<div id="intro">
    <p>To be able to use this tool you need a maintainer Account, and a role in the target DB.
    <p>Only PostgreSQL Databases are supported.
</div>